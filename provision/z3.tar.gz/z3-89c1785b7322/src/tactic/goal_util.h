/*++
Copyright (c) 2012 Microsoft Corporation

Module Name:

    goal_util.h

Abstract:

    goal goodies.

Author:

    Leonardo de Moura (leonardo) 2012-01-03.

Revision History:

--*/
#ifndef _GOAL_UTIL_H_
#define _GOAL_UTIL_H_

class goal;
bool has_term_ite(goal const & g);

#endif
